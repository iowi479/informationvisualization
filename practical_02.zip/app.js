"use strict";

function getTutorialInfo() {
  return {
    exerciseNum: 2,  //make sure that this is the right number of the current exercise
    groupNames: "Jane Doe, Max Mustermann", //provide the names of each team member
  };
}

function draw(two) {
  // get data
  const pokemons_per_type = getData();
  // logging the data to console (you can remove this code or comment it out)
  const pokemon_types = Object.keys(pokemons_per_type);
  const colors = getColorMap()

  console.log('NUMBER OF TYPES: ' + pokemon_types.length);

  for (const type of pokemon_types) {
    console.log('TYPE 1: ' + type + ' [color: ' + colors[type] + ']');
    const mons = pokemons_per_type[type];
    mons.forEach(mon => console.log('   ' + mon.type2 + ' : ' + mon.name + ' (' + mon.id + ')'))
  }
  // draw a background grid (not neccesarily needed)
  makeBGDots(two);

  // TODO: put code for part e) here, you can also call and test your functions here
}

/**
 * Creates a group that contains a Rectangle and a label in the lower right corner that tells the type.
 * @param {Two} two
 *    the two.js object to create shapes with
 * @param {String} type
 *    the pokemon type
 * @returns a group containing the shapes created by this method
 */
function makeRectForType(two, type) {
  // TODO: put code for part d) here
}

/**
 * Creates a group that contains a circle for each pokemon in the array.
 * The circles are arranged in a 6x6 grid and colored according to the
 * type2 of the corresponding pokemon.
 * @param {Two} two
 *    the two.js object to create shapes with
 * @param {Array.<{name: String, id: int, type2: String}>} mons
 *    the array of pokemons to create circles for
 * @returns a group containing the shapes created by this method
 */
function makeCirclesForMons(two, mons) {
  // TODO: put code for part c) here
}

/**
 * Creates a group containing a circle that is colored according to the type2 of the pokemon.
 * @param {Two} two
 *    the two.js object to create shapes with
 * @param {{name: String, id: int, type2: String}} mon
 *    the pokemon for which a circle is generated
 * @returns a group containing the shapes created by this method
 */
function makeCircleForMon(two, mon) {
  // TODO: put code for part b) here
}

/**
 * Creates a grid consisting of small dots.
 * @param {Two} two
 *    the two.js object to create shapes with
 * @returns a group containing the shapes created by this method
 */
function makeBGDots(two) {
  const group = two.makeGroup();
  for (let row = 0; row < 50; row++) {
    for (let col = 0; col < 50; col++) {
      const rect = two.makeRectangle(col*22, row*22, 1, 1);
      rect.stroke = rect.fill = '#778899'
      group.add(rect);
    }
  }
  group.translation.set(13, 13);
  return group;
}


