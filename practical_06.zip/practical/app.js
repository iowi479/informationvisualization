"use strict";

function getTutorialInfo() {
    return {
        exerciseNum: 6,
        groupNames: "Your last names here",
        isAnimated: true
    }
}

function draw(two) {
    // get data set
    const dataTable = getData().data;
    const dataLabels = getData().labels;
    const n = dataTable.length;
    // calculate pairwise dissimilarities between data items
    const dissimilarities = calcDissimilarityMatrix(dataTable);
    // get 2D points and show them
    let points = getInitialPoints(n);
    assignPointAppearance(n, dissimilarities, points, dataLabels);
    drawPoints(two, points, 0);
    drawStressText(two, stress_all(n, dissimilarities, points));

    // This is where the outermost for-loop of the algorithm is implicitly implemented.
    two.bind('update',
        frameCount => {
            if (frameCount > totalIterations) {
                two.pause();
                return;
            }
            const iteration = frameCount;

            // reset the points
            if (iteration === 0) {
                points = getInitialPoints(n);
            }
            // calculate gradients and update points
            mdsStep(n, dissimilarities, points);
            // assign colors to points
            assignPointAppearance(n, dissimilarities, points, dataLabels);

            // Removes the current drawing from the instance's scene
            two.clear();

            // draws the points
            drawPoints(two, points, iteration)
            drawStressText(two, stress_all(n, dissimilarities, points));
        });
}

/**
 * Calculates the dissimilarities between data items in dataTable.
 * The resulting matrix contains the distance between dataTable[i] and dataTable[j]
 * at entry matrix[i][j].
 * @param dataTable array of arrays where dataTable[i] is a data point of several dimensions
 * @return dissimilarity matrix
 */
function calcDissimilarityMatrix(dataTable){
   const n = dataTable.length;
   const matrix = getDummyDissimilarities(n);
   // TODO: insert code here (overwrite the dummy values)
   return matrix;
}

/**
 * Calculates the euclidean distance between two high-dimensional vectors
 * @param a array of numbers
 * @param b other array of numbers
 * @returns distance ||a-b||
 */
function euclideanDistance(a,b) {
  let sum = 0;
  for(let i = 0; i < a.length; i++){
    sum += (a[i]-b[i])**2
  }
  return Math.sqrt(sum);
}

/**
 * Computes the pairwise stress for points i and j.
 * @param i index of point
 * @param j index of other point
 * @param dissimilarities dissimilarity matrix D[i][j]
 * @param points array of points (Two.Vector[])
 * @returns pairwise stress (squared difference between dissimilarity and point distance)
 */
function stress(i, j, dissimilarities, points) {
  // TODO: insert code here
  return 0;
}

/**
 * Computes the overall stress
 * @param n number of points
 * @param dissimilarities dissimilarity matrix D[i][j]
 * @param points array of points (Two.Vector[])
 * @returns sum of all pairwise stresses
 */
function stressAll(n, dissimilarities, points) {
  let sum = 0;
  // TODO: insert code here
  return sum;
}

/**
 * Computes the gradient of point i.
 * @param i index of the gradient to be calculated
 * @param n number of points
 * @param dissimilarities dissimilarity matrix D[i][j]
 * @param points array of points (Two.Vector[])
 * @returns the gradient
 */
function gradient(i, n, dissimilarities, points) {
  const eps = 1e-8;
  let delta = new Two.Vector(0,0);
  // TODO: insert code here
  return delta;
}


/**
 * Computes the gradient (according to the MDS stress) for each point
 * and updates the position of each point (in gradient descent fashion).
 * @param n number of points
 * @param dissimilarities dissimilarity matrix D[i][j]
 * @param points array of points
 */
function mdsStep(n, dissimilarities, points) {
  // TODO: insert code here
}

/**
 * Assigns a color (and line width) to each point
 * @param n number of points
 * @param dissimilarities dissimilarity matrix D[i][j]
 * @param points array of points
 * @param labels the (class) labels corresponding to the points
 */
function assignPointAppearance(n, dissimilarities, points, labels) {
  // TODO: insert code here
  for(let i=0; i<n; i++) {
    switch(labels[i]) {
      case 'setosa':
        points[i].color = '#e41a1c';
        break;
      case 'virginica':
        points[i].color = '#377eb8';
        break;
      default:
        points[i].color = '#984ea3';
    }
  }
}





